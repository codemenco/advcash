<?php
namespace Codemenco\AdvCash\Exceptions;


class AdvCashException extends \Exception
{

}